    <div class="footer_overlay"></div>
    <footer class="footer">
        <div class="footer_background" style="background-image:url(public/images/footer.jpg)"></div>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="footer_content d-flex flex-lg-row flex-column align-items-center justify-content-lg-start justify-content-center">
                        <div class="footer_logo"><a href="#" style="font-family: 'Akronim', cursive;font-size: 3rem">Netherrealm</a></div>
                        <div class="copyright ml-auto mr-auto"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> Bản quyền thuộc về <i class="fa fa-heart-o" aria-hidden="true"></i>  Netherrealm</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
                        
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>

<script src="public/js/jquery-3.2.1.min.js"></script>
<script src="public/styles/bootstrap4/popper.js"></script>
<script src="public/styles/bootstrap4/bootstrap.min.js"></script>
<script src="public/plugins/greensock/TweenMax.min.js"></script>
<script src="public/plugins/greensock/TimelineMax.min.js"></script>
<script src="public/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="public/plugins/greensock/animation.gsap.min.js"></script>
<script src="public/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="public/plugins/easing/easing.js"></script>
<script src="public/plugins/parallax-js-master/parallax.min.js"></script>
<script src="public/js/cart.js"></script>
</body>
</html>