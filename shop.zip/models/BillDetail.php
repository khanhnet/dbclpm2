<?php 
include_once('Model.php');
    class BillDetail extends Model
    {
      var $table='detail_bill';
      var $key ='CODE';
}

?>