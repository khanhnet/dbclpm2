<?php 
include_once('Model.php');
    class Employee extends Model
    {
      var $table='employees';
      var $key ='CODE';
}


?>