<?php 

define('servername','localhost');
define('username','id14776314_root');
define('password','=#]w<5hBr1*J>\*x');
define('dbname','id14776314_php_shop');
 ?>