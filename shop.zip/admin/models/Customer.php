<?php 
include_once('Model.php');
    class Customer extends Model
    {
      var $table='customers';
      var $key ='CODE';
}


?>